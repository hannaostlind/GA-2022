# SwaggerClient::TimetableInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**time_table_data** | [**TimeTableData**](TimeTableData.md) |  | 
**time_table_period** | [**TimeTablePeriod**](TimeTablePeriod.md) |  | 


