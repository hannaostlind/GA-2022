# SwaggerClient::JourneyId

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** | ID of this journey | 
**route_idx_to** | **Integer** | End of validity on total route | 
**route_idx_from** | **Integer** | Start of validity on total route | 


