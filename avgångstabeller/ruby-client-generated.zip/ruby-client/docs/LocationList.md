# SwaggerClient::LocationList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**error_text** | **String** |  | [optional] 
**error** | **String** |  | [optional] 
**serverdate** | **Date** |  | [optional] 
**servertime** | **String** | Current server time in format HH:MM | [optional] 
**stop_location** | [**Array&lt;StopLocation&gt;**](StopLocation.md) |  | [optional] 
**coord_location** | [**Array&lt;CoordLocation&gt;**](CoordLocation.md) |  | [optional] 
**no_namespace_schema_location** | **String** |  | 


