# SwaggerClient::DateEnd

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **Date** | End of timetable period in format YYYY-MM-DD | 


