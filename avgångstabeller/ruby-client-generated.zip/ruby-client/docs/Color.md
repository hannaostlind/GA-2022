# SwaggerClient::Color

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bg_color** | **String** | Backgroundcolor of this line | 
**fg_color** | **String** | Foregroundcolor of this line | 
**stroke** | **String** | Stroke style of this line | 


