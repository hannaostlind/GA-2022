# SwaggerClient::Point

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**lon** | **String** |  | 
**lat** | **String** |  | 


