# SwaggerClient::Direction

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**route_idx_to** | **Integer** | End of validity on total route | 
**value** | **String** |  | 
**route_idx_from** | **Integer** | Start of validity on total route | 


