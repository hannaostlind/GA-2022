# SwaggerClient::DateBegin

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **Date** | Begin of timetable period in format YYYY-MM-DD | 


