# SwaggerClient::JourneyName

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**route_idx_to** | **Integer** | End of validity on total route. | 
**route_idx_from** | **Integer** | Start of validity on total route | 
**name** | **String** | Name to be displayed | 


