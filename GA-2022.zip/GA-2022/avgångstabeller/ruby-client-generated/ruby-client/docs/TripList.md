# SwaggerClient::TripList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**error_text** | **String** |  | [optional] 
**error** | **String** |  | [optional] 
**serverdate** | **Date** |  | [optional] 
**servertime** | **String** | Current server time in format HH:MM | [optional] 
**trip** | [**Array&lt;Trip&gt;**](Trip.md) |  | [optional] 
**no_namespace_schema_location** | **String** |  | 


