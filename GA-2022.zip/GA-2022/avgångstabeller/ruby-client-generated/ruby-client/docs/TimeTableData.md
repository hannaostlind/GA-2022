# SwaggerClient::TimeTableData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**creation_date** | [**CreationDate**](CreationDate.md) |  | 


