# SwaggerClient::TimeTablePeriod

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**date_begin** | [**DateBegin**](DateBegin.md) |  | 
**date_end** | [**DateEnd**](DateEnd.md) |  | 


