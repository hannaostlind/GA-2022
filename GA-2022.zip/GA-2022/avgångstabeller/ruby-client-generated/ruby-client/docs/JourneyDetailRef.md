# SwaggerClient::JourneyDetailRef

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ref** | **String** | Contains a URL to call the REST interface for journey details | 


