# SwaggerClient::CreationDate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **Date** | Creation date of timetable data in format YYYY-MM-DD | 


