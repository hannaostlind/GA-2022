# SwaggerClient::ArrivalBoard

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**error_text** | **String** |  | [optional] 
**error** | **String** |  | [optional] 
**serverdate** | **Date** |  | [optional] 
**servertime** | **String** | Current server time in format HH:MM | [optional] 
**arrival** | [**Array&lt;Arrival&gt;**](Arrival.md) |  | [optional] 
**no_namespace_schema_location** | **String** |  | 


