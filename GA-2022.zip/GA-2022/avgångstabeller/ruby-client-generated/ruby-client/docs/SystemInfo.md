# SwaggerClient::SystemInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**timetable_info** | [**TimetableInfo**](TimetableInfo.md) |  | [optional] 
**error_text** | **String** |  | [optional] 
**error** | **String** |  | [optional] 
**serverdate** | **Date** |  | [optional] 
**servertime** | **String** | Current server time in format HH:MM | [optional] 
**no_namespace_schema_location** | **String** |  | 


