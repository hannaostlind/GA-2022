# SwaggerClient::Points

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**point** | [**Array&lt;Point&gt;**](Point.md) |  | 


