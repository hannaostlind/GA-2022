# SwaggerClient::Notes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**note** | [**Array&lt;Note&gt;**](Note.md) |  | [optional] 


