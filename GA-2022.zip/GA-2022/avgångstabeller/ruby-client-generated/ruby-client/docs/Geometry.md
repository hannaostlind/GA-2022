# SwaggerClient::Geometry

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**error_text** | **String** |  | [optional] 
**error** | **String** |  | [optional] 
**serverdate** | **Date** |  | [optional] 
**servertime** | **String** | Current server time in format HH:MM | [optional] 
**points** | [**Array&lt;Points&gt;**](Points.md) |  | [optional] 
**no_namespace_schema_location** | **String** |  | 


