# SwaggerClient::DepartureBoard

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**error_text** | **String** |  | [optional] 
**departure** | [**Array&lt;Departure&gt;**](Departure.md) |  | [optional] 
**error** | **String** |  | [optional] 
**serverdate** | **Date** |  | [optional] 
**servertime** | **String** | Current server time in format HH:MM | [optional] 
**no_namespace_schema_location** | **String** |  | 


