# SwaggerClient::GeometryRef

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ref** | **String** | Contains a URL to call the REST interface for geometry | 


